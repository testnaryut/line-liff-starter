<!-- This file allows you to host this page as a static file on Heroku -->
<?php header( 'Location: /index.html' ) ;  ?>